import React from "react";
import { Text, View } from "react-native";

export default function App() {
  return (
    <View>
      <Text>red</Text>
      <Text>green</Text>
      <Text>blue</Text>
    </View>
  );
}
