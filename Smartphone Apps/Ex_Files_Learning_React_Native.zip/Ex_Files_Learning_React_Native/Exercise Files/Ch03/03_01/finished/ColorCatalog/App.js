import React from "react";
import {
  ActivityIndicator,
  View,
  ProgressViewIOS,
  Button
} from "react-native";

export default function App() {
  const onButtonPress = () => {
    console.log(
      `${new Date().toLocaleTimeString()} button press`
    );
  };
  return (
    <View style={{ padding: 50 }}>
      <ProgressViewIOS progress={0.5} />
      <ActivityIndicator
        size="large"
        color="#61DBFB"
      ></ActivityIndicator>
      <Button title="click me" onPress={onButtonPress} />
    </View>
  );
}
