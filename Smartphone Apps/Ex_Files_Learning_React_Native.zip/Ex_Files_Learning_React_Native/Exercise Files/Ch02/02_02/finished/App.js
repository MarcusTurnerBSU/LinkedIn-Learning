// This is the code that we typed into Expo Snack.
// You can view this running here: https://snack.expo.io/h6bFTzw!u

import React from "react";
import { Text, View } from "react-native";

export default function App() {
  return (
    <View style={{ padding: 50 }}>
      <Text>Hello World</Text>
      <Text>Red</Text>
      <Text>Green</Text>
      <Text>Blue</Text>
    </View>
  );
}
