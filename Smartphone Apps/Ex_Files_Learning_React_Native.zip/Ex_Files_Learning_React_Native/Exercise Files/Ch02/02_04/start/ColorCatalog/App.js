import React from "react";
import { Text, View } from "react-native";

export default function App() {
  return (
    <View style={{ padding: 50 }}>
      <Text>ready...</Text>
    </View>
  );
}
