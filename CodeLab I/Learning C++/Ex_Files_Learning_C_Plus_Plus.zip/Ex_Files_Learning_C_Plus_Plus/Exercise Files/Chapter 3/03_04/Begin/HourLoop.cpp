#include <iostream> 
 #include <ctime>
 #include <cstdlib>
using namespace std; 
 

int main()  
{  
  for (int h = 0; h < 24; h++)
  {
  	cout << h << ":00\n";
  }
 
}
