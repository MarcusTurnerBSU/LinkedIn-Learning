//Happy Birthday to demonstrate functions
//by Erin Colvin
//It's not really my birthday :)
#include <iostream> 
using namespace std; 
 
//function prototype 
void PrintHBD();

int main()  
{  
    //calling statement
  	PrintHBD();
  	PrintHBD();
  	cout << "Happy Birthday dear user\n";
  	PrintHBD();
}

//function header
void PrintHBD()
{
	cout << "Happy Birthday to you\n";
}

