//Happy Birthday to demonstrate functions
//by Erin Colvin
//It's not really my birthday :)
#include <iostream> 
using namespace std; 
 
int main()
{
	cout << "Happy Birthday to you\n";
	cout << "Happy Birthday to you\n";
	cout << "Happy Birthday dear user\n";
	cout << "Happy Birthday to you\n";
}
