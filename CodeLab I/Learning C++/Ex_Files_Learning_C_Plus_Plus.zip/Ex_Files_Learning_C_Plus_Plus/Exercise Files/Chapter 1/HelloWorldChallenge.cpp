//Hello World
/* By Erin Colvin */
//iostream used for inputting and outputting
#include <iostream>
using namespace std;


//////////////////////////////////////
//Main is always the first to run
/////////////////////////////////////
int main()
{
	string name;
	cout << "Please enter your name: " << endl;
	cin >> name;
	cout <<  "Hello, " << name << endl;
	return 0;
}
