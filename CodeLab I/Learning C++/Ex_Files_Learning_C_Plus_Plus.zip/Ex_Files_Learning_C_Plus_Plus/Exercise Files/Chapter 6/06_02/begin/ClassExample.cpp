#include <iostream> 

using namespace std; 
 
class BankAccount
{
  private: 
	float balance;

  public:    
    BankAccount();  
	void Deposit(float);
    void WithDrawl();
	
};


int main() 
{

	
    
}



