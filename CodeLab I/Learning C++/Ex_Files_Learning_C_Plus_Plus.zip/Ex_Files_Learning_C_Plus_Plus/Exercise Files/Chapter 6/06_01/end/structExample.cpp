#include <iostream> 

using namespace std; 
 

struct students
{
	string name;
	float GPA;
};

int main() 
{
    
	
    
}



