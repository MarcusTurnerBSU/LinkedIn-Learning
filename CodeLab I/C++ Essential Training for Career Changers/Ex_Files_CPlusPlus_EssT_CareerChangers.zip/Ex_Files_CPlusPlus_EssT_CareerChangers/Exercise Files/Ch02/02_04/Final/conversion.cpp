#include <iostream>
using namespace std;

/* run this program using the console pauser or add your own getch, system("pause") or input loop */

int main(int argc, char** argv) {
	double x{45.765};
	int y = static_cast<int>(x);
	int b = true;
	int c = 'a';
	cout<<"x: "<<x<<endl;
	cout<<"y: "<<y<<endl;
	cout<<"b: "<<b<<endl;
	cout<<"c: "<<c<<endl;
	
	return 0;
}
