#include <iostream>
#include <iomanip>
using namespace std;

/* run this program using the console pauser or add your own getch, system("pause") or input loop */

int main(int argc, char** argv) {
	cout<<"AL"<<"Alabama"<<4.00<<"%"<<endl;
	cout<<"AZ"<<"Arizona"<<5.60<<"%"<<endl;
	cout<<"AR"<<"Arkansas"<<6.50<<"%"<<endl;
	cout<<"CA"<<"California"<<6.00<<"%"<<endl;
	cout<<"CO"<<"Colorado"<<2.90<<"%"<<endl;
	return 0;
}
